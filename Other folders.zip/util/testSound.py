import playsound
filename = "./photo/SigovAS.mp3"
playsound.playSound(filename)