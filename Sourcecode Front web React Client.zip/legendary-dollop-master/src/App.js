import MainLayout from './layouts/MainLayout/MainLayout.tsx';
import './App.css';

function App() {
  return (
    <div className="App">
      <MainLayout />
    </div>
  );
}

export default App;
