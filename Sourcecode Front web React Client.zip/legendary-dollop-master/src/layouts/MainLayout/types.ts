export type Item = {
  id: string | null,
  name: string | null,
  cadr: string | null,
  desc: string | null,
  photo: string | null,
};